
# 🛠️ Instrucciones para agregar Hilt al proyecto

Estas instrucciones usan `libs.versions.toml` como base para la configuración.

---

## ✅ 1. Agregar las versiones en `[versions]` de `libs.versions.toml`

```toml
hilt = "2.52"
```

---

## ✅ 2. Agregar las dependencias en `[libraries]`

```toml
hilt-android = { group = "com.google.dagger", name = "hilt-android", version.ref = "hilt" }
hilt-compiler = { group = "com.google.dagger", name = "hilt-android-compiler", version.ref = "hilt" }
hilt-android-gradle-plugin = { group = "com.google.dagger", name = "hilt-android-gradle-plugin", version.ref = "hilt" }
dagger-android-processor = { group = "com.google.dagger", name = "dagger-android-processor", version.ref = "hilt" }
androidx-hilt-navigation-compose = { module = "androidx.hilt:hilt-navigation-compose", version = "1.1.0" }
```

---

## ✅ 3. Agregar el plugin en `[plugins]`

```toml
dagger-hilt-android = { id = "com.google.dagger.hilt.android", version.ref = "hilt" }
```

---

## ✅ 4. Usarlo en el archivo `build.gradle.kts` del módulo `:app`

### Bloque `plugins`

```kotlin
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    id("kotlin-kapt") // SE USA DIRECTAMENTE, no desde alias
    alias(libs.plugins.dagger.hilt.android)
}
```

(*) `kotlin-kapt` no debe usarse vía alias porque es un plugin especial que ya está en el classpath.

---

### Bloque `dependencies`

```kotlin
dependencies {
    implementation(libs.hilt.android)
    implementation(libs.hilt.android.gradle.plugin)
    kapt(libs.dagger.android.processor)
    kapt(libs.hilt.compiler)
    implementation(libs.androidx.hilt.navigation.compose)
}
```

---

## ✅ 5. Crear `EccomerceApp.kt`

```kotlin
@HiltAndroidApp
class EccomerceApp : Application()
```

Y en tu `AndroidManifest.xml`:

```xml
<application
    android:name=".EccomerceApp"
    ...>
```

---

## ✅ 6. Crear módulo de Hilt (ej: `AuthModule.kt`)

```kotlin
@Module
@InstallIn(SingletonComponent::class)
object AuthModule {

    @Provides
    @Singleton
    fun provideAuthRepository(): AuthRepository = AuthRepositoryImpl()
}
```

---

## ✅ 7. Importaciones necesarias

```kotlin
import javax.inject.Inject
import javax.inject.Singleton
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.HiltAndroidApp
import dagger.hilt.android.lifecycle.HiltViewModel
```

---

# 🧪 ¿Por qué se necesitan estas dependencias de Hilt?

Este archivo explica para qué sirven y por qué son necesarias las siguientes dependencias en el proyecto:

---

## ✅ 1. `hilt-android`

```toml
hilt-android = { group = "com.google.dagger", name = "hilt-android", version.ref = "hilt" }
```

### 📌 ¿Para qué sirve?
Es la **librería base de Hilt**, necesaria para:
- Inyectar dependencias con `@Inject`
- Anotar clases con `@HiltAndroidApp`, `@Module`, `@InstallIn`
- Inyectar clases como ViewModels, Repositorios, etc.

### 📎 Ejemplo:
```kotlin
class MyRepository @Inject constructor()
```

---

## ✅ 2. `hilt-compiler`

```toml
hilt-compiler = { group = "com.google.dagger", name = "hilt-android-compiler", version.ref = "hilt" }
```

### 📌 ¿Para qué sirve?
Es el **procesador de anotaciones de Hilt**:
- Necesario para que funciones como `@HiltViewModel`, `@Inject` o `@Module` generen código válido en tiempo de compilación.
- Requiere tener habilitado `kapt` en tu build.gradle.kts

### 📎 Ejemplo:
```kotlin
@HiltViewModel
class LoginViewModel @Inject constructor(...) : ViewModel()
```

---

## ✅ 3. `androidx-hilt-navigation-compose`

```toml
androidx-hilt-navigation-compose = { module = "androidx.hilt:hilt-navigation-compose", version = "1.1.0" }
```

### 📌 ¿Para qué sirve?
Integra Hilt con **Jetpack Compose**:
- Permite usar `hiltViewModel()` dentro de tus `@Composable`.
- Evita tener que pasar manualmente los ViewModels a cada pantalla.

### 📎 Ejemplo:
```kotlin
@Composable
fun LoginScreen(viewModel: LoginViewModel = hiltViewModel()) {
    // usar el viewmodel directamente
}
```

---

## ✅ En resumen:

| Dependencia                        | ¿Para qué sirve?                                   | ¿Es obligatoria? |
|-----------------------------------|----------------------------------------------------|------------------|
| `hilt-android`                    | Base de Hilt, inyección de dependencias            | ✅ Sí            |
| `hilt-compiler`                   | Generación de código con anotaciones               | ✅ Sí            |
| `androidx-hilt-navigation-compose`| Integración con Jetpack Compose                    | 🟡 Recomendado   |
